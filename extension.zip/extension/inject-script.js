try {
    if (typeof __NEXT_DATA__ !== 'undefined') {
        document.getElementsByTagName("body")[0].setAttribute("tmp___NEXT_DATA__", JSON.stringify(__NEXT_DATA__))
    }
} catch (error) { }